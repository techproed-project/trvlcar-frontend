import React from 'react'

const UserTemplate = () => {
  return (
    <div>UserTemplate</div>
  )
}

export default UserTemplate