export const userInitialState = {
    user:{},
    isUserLogin: false
};