export const types = {
    LOGIN_SUCCESS : "LOGIN_SUCCESS",
    LOGIN_FAILED: "LOGIN_FAILED",
    LOGOUT: "LOGOUT"
};