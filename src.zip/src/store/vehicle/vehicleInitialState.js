export const vehicleInitialState = {
    vehicles:[]
}