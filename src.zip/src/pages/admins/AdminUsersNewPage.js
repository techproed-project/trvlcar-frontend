import React from 'react'

const AdminUsersNewPage = () => {
  return (
    <div>AdminUsersNewPage</div>
  )
}

export default AdminUsersNewPage