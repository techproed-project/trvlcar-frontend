import React from 'react'

const AdminUsersEditPage = () => {
  return (
    <div>AdminUsersEditPage</div>
  )
}

export default AdminUsersEditPage