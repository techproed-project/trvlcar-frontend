import React from 'react'
import { Container } from 'react-bootstrap'

const AdminDashboardPage = () => {
  return (
    <Container>AdminDashboardPage</Container>
  )
}

export default AdminDashboardPage