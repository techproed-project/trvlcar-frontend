import React from 'react'
import Auth from '../../components/users/auth/auth'

const AuthPage = () => {
  return (
    <Auth/>
  )
}

export default AuthPage