import React from 'react'
import PageHeader from '../../components/users/common/page-header/page-header'

const VehiclesPage = () => {
  return (
    <>
    <PageHeader title="Vehicles"/>
    </>
  )
}

export default VehiclesPage