import React from 'react'
import Slider from '../../components/users/home/slider/slider'

const HomePage = () => {
  return (
    <>
      <Slider/>
    </>
  )
}

export default HomePage