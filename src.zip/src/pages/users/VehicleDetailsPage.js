import React from 'react'
import PageHeader from '../../components/users/common/page-header/page-header'

const VehicleDetailsPage = () => {
  return (
    <>
    <PageHeader title="Vehicle Details"/>
    </>
  )
}

export default VehicleDetailsPage