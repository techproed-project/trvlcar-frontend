import React from 'react'

const VehicleDetailsPage = () => {
  return (
    <div>VehicleDetailPage</div>
  )
}

export default VehicleDetailsPage