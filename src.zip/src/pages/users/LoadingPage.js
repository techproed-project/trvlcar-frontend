import React from 'react'
import Loading from '../../components/users/loading/loading'

const LoadingPage = () => {
  return (
    <Loading/>
  )
}

export default LoadingPage