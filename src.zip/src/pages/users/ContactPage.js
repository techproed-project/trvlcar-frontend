import React from 'react'
import PageHeader from '../../components/users/common/page-header/page-header'

const ContactPage = () => {
  return (
    <>
    <PageHeader title="Contact Us"/>
    </>
      
  )
}

export default ContactPage