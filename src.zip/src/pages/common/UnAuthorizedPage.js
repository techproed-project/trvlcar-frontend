import React from 'react'

const UnAuthorizedPage = () => {
  return (
    <div>UnAuthorized</div>
  )
}

export default UnAuthorizedPage